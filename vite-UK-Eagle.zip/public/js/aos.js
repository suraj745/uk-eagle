//
import Aos from "aos";

Aos.init();
