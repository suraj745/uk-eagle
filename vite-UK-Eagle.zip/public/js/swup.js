// import Lenis from "@studio-freight/lenis";

// const lenis = new Lenis();
