export function select(e) {
  return document.querySelector(e);
}
export function selectAll(e) {
  return document.querySelectorAll(e);
}
